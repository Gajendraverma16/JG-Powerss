import './index.css'

function App() {

  return (
    <>
    <div>
      <h1>Page live</h1>
    </div>
    </>
  )
}

export default App
