import React from 'react'

const ViewPayment = () => {
  return (
    <div>ViewPayment</div>
  )
}

export default ViewPayment
