import React from 'react'

const CreatePayment = () => {
  return (
    <div>CreatePayment</div>
  )
}

export default CreatePayment
