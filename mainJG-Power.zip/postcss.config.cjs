// postcss.config.cjs
module.exports = {
  plugins: {
    // Use the new PostCSS plugin entrypoint
    '@tailwindcss/postcss': {},
    autoprefixer: {},
  },
}
